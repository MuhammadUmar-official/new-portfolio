import { motion } from 'motion/react';
import { Terminal, Database, Presentation, LineChart, Code2, Cpu } from 'lucide-react';

const skillCategories = [
  {
    title: "Data Engineering",
    icon: <Database className="text-blue-400" />,
    skills: ["Python", "DSA Problem Solving", "SQL", "Data Cleaning", "Feature Engineering"]
  },
  {
    title: "Machine Learning",
    icon: <Cpu className="text-purple-400" />,
    skills: ["Predictive Modeling", "Hypothesis Testing", "Regression", "Classification", "Model Metrics"]
  },
  {
    title: "Data Viz",
    icon: <Presentation className="text-green-400" />,
    skills: ["Matplotlib", "Seaborn", "EDA", "Statistical Analysis", "Reporting"]
  },
  {
    title: "Tools & Libraries",
    icon: <Code2 className="text-orange-400" />,
    skills: ["NumPy", "Pandas", "Scikit-learn", "Git", "Advanced Math"]
  }
];

export default function Skills() {
  return (
    <section id="skills" className="py-24 px-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-8 text-left">
        <div>
          <h2 className="text-4xl md:text-6xl mb-4">Technical <span className="text-gradient">Arsenal</span></h2>
          <p className="text-slate-400 max-w-sm">Specializing in the tools that power intelligent decisions.</p>
        </div>
        <div className="text-6xl md:text-8xl font-display font-black text-white/5 uppercase select-none">
          Stack
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {skillCategories.map((cat, i) => (
          <motion.div
            key={cat.title}
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.1 }}
            viewport={{ once: true }}
            className="glass-card p-8 group hover:bg-white/5 transition-colors"
          >
            <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              {cat.icon}
            </div>
            <h3 className="text-xl mb-4 font-display font-semibold text-white">{cat.title}</h3>
            <div className="flex flex-wrap gap-2">
              {cat.skills.map((skill) => (
                <span key={skill} className="px-3 py-1 bg-white/5 border border-white/10 rounded-lg text-xs font-mono text-slate-400">
                  {skill}
                </span>
              ))}
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
