import { motion } from 'motion/react';
import { Github, Linkedin, Mail, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/src/lib/utils';

const navItems = [
  { name: 'Home', href: '#' },
  { name: 'About', href: '#about' },
  { name: 'Skills', href: '#skills' },
  { name: 'Experience', href: '#experience' },
  { name: 'Contact', href: '#contact' },
];

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 w-full z-50 px-6 py-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between glass-card px-6 py-3">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-xl font-display font-bold text-gradient"
        >
          MU.
        </motion.div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center space-x-8">
          {navItems.map((item, i) => (
            <motion.a
              key={item.name}
              href={item.href}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="text-[0.875rem] font-medium text-text-dim hover:text-white uppercase tracking-[0.05em] transition-colors"
            >
              {item.name}
            </motion.a>
          ))}
        </div>

        {/* Socials */}
        <div className="hidden md:flex items-center space-x-4">
          <a href="https://github.com/MuhammadUmar-official" target="_blank" rel="noopener noreferrer" className="p-2 hover:bg-white/10 rounded-full transition-colors">
            <Github size={20} />
          </a>
          <a href="https://www.linkedin.com/in/muhammad-umar-ai-ml" target="_blank" rel="noopener noreferrer" className="p-2 hover:bg-white/10 rounded-full transition-colors">
            <Linkedin size={20} />
          </a>
          <a href="mailto:hiumar937@gmail.com" className="p-2 hover:bg-white/10 rounded-full transition-colors">
            <Mail size={20} />
          </a>
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden p-2" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden mt-2 glass-card p-6 flex flex-col space-y-4"
        >
          {navItems.map((item) => (
            <a
              key={item.name}
              href={item.href}
              onClick={() => setIsOpen(false)}
              className="text-lg font-medium hover:text-brand-primary transition-colors"
            >
              {item.name}
            </a>
          ))}
          <div className="flex space-x-4 pt-4 border-t border-white/10">
            <a href="https://github.com/MuhammadUmar-official" target="_blank" rel="noopener noreferrer"><Github size={24} /></a>
            <a href="https://www.linkedin.com/in/muhammad-umar-ai-ml" target="_blank" rel="noopener noreferrer"><Linkedin size={24} /></a>
            <a href="mailto:hiumar937@gmail.com"><Mail size={24} /></a>
          </div>
        </motion.div>
      )}
    </nav>
  );
}
