import { motion } from 'motion/react';
import { Calendar, MapPin, Building2 } from 'lucide-react';

const experiences = [
  {
    company: "AfterQuery Experts",
    role: "Data Science Project Contributor",
    period: "Feb 2026 - Present",
    location: "United States (Remote)",
    desc: "Focusing on data cleaning, exploratory data analysis, and building machine learning models for predictive insights. Collaborating on solving real-world data problems by identifying patterns and developing accurate models."
  },
  {
    company: "Freelance",
    role: "Data Scientist Consultant",
    period: "April 2025 - Present",
    location: "Global",
    desc: "Helping businesses leverage data to improve performance and make informed decisions. Expertise in data cleaning, predictive analytics, and trend identification using Python, Pandas, and NumPy."
  },
  {
    company: "Xeven Solutions",
    role: "Data Scientist",
    period: "Jan 2025 - Feb 2026",
    location: "Lahore, Pakistan",
    desc: "Specialized in predictions and building ML models for accurate trend identification. Leveraged tools like Python and Scikit-learn to transform raw data into actionable business intelligence."
  },
  {
    company: "CodeAlpha",
    role: "Machine Learning Engineer",
    period: "Dec 2025 - Jan 2026",
    location: "India (Remote)",
    desc: "Developed salary prediction models using regression. Built credit card fraud detection using classification and anomaly detection. Worked on multiple classification models like Random Forest and SVM."
  }
];

export default function Experience() {
  return (
    <section id="experience" className="py-24 px-6 max-w-5xl mx-auto">
      <div className="text-center mb-20">
        <h2 className="text-4xl md:text-6xl mb-6">Career <span className="text-gradient">Timeline</span></h2>
        <p className="text-slate-400">A journey through data science and intelligence engineering.</p>
      </div>

      <div className="space-y-12 relative before:absolute before:left-0 md:before:left-1/2 before:w-[1px] before:h-full before:bg-white/10">
        {experiences.map((exp, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            viewport={{ once: true }}
            className={`flex flex-col md:flex-row gap-8 relative items-center ${i % 2 === 0 ? 'md:flex-row-reverse' : ''}`}
          >
            {/* Dot */}
            <div className="absolute left-0 md:left-1/2 w-4 h-4 rounded-full bg-brand-primary border-4 border-bg-dark -translate-x-1/2 z-10" />

            <div className="w-full md:w-1/2">
              <div className="glass-card p-8 hover:border-brand-primary/50 transition-colors">
                <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-brand-primary uppercase mb-4">
                  <span className="flex items-center gap-1"><Calendar size={12} /> {exp.period}</span>
                  <span className="flex items-center gap-1"><MapPin size={12} /> {exp.location}</span>
                </div>
                <h3 className="text-2xl font-display mb-1">{exp.role}</h3>
                <div className="flex items-center gap-2 text-slate-400 mb-4">
                  <Building2 size={16} />
                  <span className="font-medium">{exp.company}</span>
                </div>
                <p className="text-slate-500 text-sm leading-relaxed">{exp.desc}</p>
              </div>
            </div>
            <div className="hidden md:block w-1/2" />
          </motion.div>
        ))}
      </div>
    </section>
  );
}
