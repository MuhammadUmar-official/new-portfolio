import { motion } from 'motion/react';
import { Mail, Linkedin, Github, Send, ExternalLink } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useState } from 'react';

export default function Contact() {
  const [formState, setFormState] = useState({ name: '', email: '', message: '' });
  const [isSent, setIsSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#00d2ff', '#3a7bd5', '#ffffff']
    });
    setIsSent(true);
    setTimeout(() => setIsSent(false), 5000);
  };

  return (
    <section id="contact" className="py-24 px-6 max-w-7xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
        <div>
          <h2 className="text-4xl md:text-6xl mb-8">Let's <span className="text-gradient">Connect</span></h2>
          <p className="text-slate-400 text-lg mb-12">
            Interested in collaboration or have a data challenge that needs solving? My inbox is always open.
          </p>

          <div className="space-y-6 mb-12">
            <a href="mailto:hiumar937@gmail.com" className="flex items-center gap-4 group">
              <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-brand-primary group-hover:text-black transition-all">
                <Mail size={20} />
              </div>
              <div>
                <div className="text-sm font-mono text-slate-500 uppercase tracking-wider">Email</div>
                <div className="text-white font-medium">hiumar937@gmail.com</div>
              </div>
            </a>
            <a href="https://www.linkedin.com/in/muhammad-umar-ai-ml" target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 group">
              <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-brand-primary group-hover:text-black transition-all">
                <Linkedin size={20} />
              </div>
              <div>
                <div className="text-sm font-mono text-slate-500 uppercase tracking-wider">LinkedIn</div>
                <div className="text-white font-medium">linkedin.com/in/muhammad-umar</div>
              </div>
            </a>
            <a href="https://github.com/MuhammadUmar-official" target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 group">
              <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-brand-primary group-hover:text-black transition-all">
                <Github size={20} />
              </div>
              <div>
                <div className="text-sm font-mono text-slate-500 uppercase tracking-wider">GitHub</div>
                <div className="text-white font-medium">github.com/MuhammadUmar-official</div>
              </div>
            </a>
          </div>

          <div className="glass-card p-6 bg-brand-primary/5 border-brand-primary/20">
            <p className="text-sm text-brand-primary italic">
              "Data is the new oil, but intelligence is the engine that drives it."
            </p>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="glass-card p-8 md:p-12"
        >
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-mono uppercase tracking-wider text-slate-500">Name</label>
                <input
                  required
                  type="text"
                  placeholder="John Doe"
                  className="w-full px-6 py-4 bg-white/5 border border-white/10 rounded-xl focus:border-brand-primary outline-none transition-colors"
                  value={formState.name}
                  onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-mono uppercase tracking-wider text-slate-500">Email</label>
                <input
                  required
                  type="email"
                  placeholder="john@example.com"
                  className="w-full px-6 py-4 bg-white/5 border border-white/10 rounded-xl focus:border-brand-primary outline-none transition-colors"
                  value={formState.email}
                  onChange={(e) => setFormState({ ...formState, email: e.target.value })}
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-mono uppercase tracking-wider text-slate-500">Message</label>
              <textarea
                required
                rows={4}
                placeholder="Tell me about your project..."
                className="w-full px-6 py-4 bg-white/5 border border-white/10 rounded-xl focus:border-brand-primary outline-none transition-colors resize-none"
                value={formState.message}
                onChange={(e) => setFormState({ ...formState, message: e.target.value })}
              />
            </div>
            <button
              disabled={isSent}
              type="submit"
              className="w-full py-4 bg-white text-black font-bold rounded-xl hover:bg-brand-primary transition-colors flex items-center justify-center gap-2 group disabled:bg-slate-700 disabled:text-slate-400"
            >
              {isSent ? 'Message Sent!' : 'Send Message'}
              {!isSent && <Send size={18} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />}
            </button>
          </form>
        </motion.div>
      </div>
    </section>
  );
}
