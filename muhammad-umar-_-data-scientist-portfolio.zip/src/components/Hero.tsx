import { motion } from 'motion/react';
import { MousePointer2, Briefcase, Database, BrainCircuit, ChevronRight } from 'lucide-react';

const stats = [
  { icon: <Briefcase size={20} />, label: "Experience", value: "2+ Years" },
  { icon: <Database size={20} />, label: "Projects", value: "15+ Completed" },
  { icon: <BrainCircuit size={20} />, label: "Specialty", value: "Machine Learning" },
];

export default function Hero() {
  return (
    <section id="home" className="min-h-screen pt-32 pb-20 px-6 relative flex flex-col items-center justify-center text-center">
      {/* Decorative Blur */}
      <div className="absolute top-1/4 -left-1/4 w-[50%] h-[50%] bg-brand-primary/20 blur-[150px] -z-10 rounded-full" />
      <div className="absolute bottom-1/4 -right-1/4 w-[50%] h-[50%] bg-brand-secondary/10 blur-[150px] -z-10 rounded-full" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8 flex items-center gap-2 text-[0.75rem] text-text-dim font-medium uppercase tracking-[0.4em]"
      >
        <span className="w-2 h-2 bg-[#22c55e] rounded-full shadow-[0_0_10px_#22c55e]" />
        Based in Lahore, PK
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="text-[4.5rem] md:text-[6.5rem] font-sans font-bold leading-[1.1] tracking-[-0.03em] mb-8 text-white"
      >
        Developing <br className="hidden md:block" />
        <span className="text-gradient">Intelligent</span> Solutions
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="text-[1.125rem] text-text-dim max-w-[480px] mb-12 leading-[1.6]"
      >
        I am a Data Scientist & ML Engineer specializing in high-performance predictive models and immersive data experiences. Transforming raw data into elegant logic.
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="flex flex-col sm:flex-row items-center gap-4 mb-20"
      >
        <a href="#contact" className="px-8 py-3.5 bg-white text-black font-semibold rounded-full hover:scale-105 transition-transform flex items-center group text-[0.875rem]">
          Get in touch
          <ChevronRight size={18} className="ml-2 group-hover:translate-x-1 transition-transform" />
        </a>
        <a href="https://github.com/MuhammadUmar-official" target="_blank" rel="noopener noreferrer" className="px-8 py-3.5 glass-card font-semibold hover:bg-white/10 transition-colors flex items-center text-[0.875rem] rounded-full">
          Latest Work
        </a>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="grid grid-cols-1 md:grid-cols-3 gap-5 w-full max-w-5xl"
      >
        {stats.map((stat, i) => (
          <div key={i} className="glass-card p-[32px] text-left group hover:border-white/20 transition-all cursor-default">
            <div className="mb-4 text-brand-primary group-hover:scale-110 transition-transform">{stat.icon}</div>
            <div className="text-[2.5rem] font-bold text-white mb-1 leading-tight">{stat.value}</div>
            <div className="text-[0.75rem] font-medium uppercase tracking-[0.1em] text-text-dim">{stat.label}</div>
          </div>
        ))}
      </motion.div>
    </section>
  );
}
