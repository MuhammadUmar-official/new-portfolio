import { motion } from 'motion/react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Skills from './components/Skills';
import Experience from './components/Experience';
import Contact from './components/Contact';
import Background3D from './components/Background3D';
import { Quote } from 'lucide-react';

function About() {
  return (
    <section id="about" className="py-24 px-6 max-w-7xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="relative group"
        >
          <div className="absolute -inset-4 bg-gradient-to-r from-brand-primary to-brand-secondary rounded-3xl blur-2xl opacity-20 group-hover:opacity-30 transition-opacity" />
          <div className="relative aspect-square glass-card overflow-hidden">
            <img 
              src="https://picsum.photos/seed/umar-data/800/800"
              alt="Muhammad Umar Profile"
              className="w-full h-full object-cover grayscale contrast-125 hover:grayscale-0 transition-all duration-700"
              referrerPolicy="no-referrer"
            />
            <div className="absolute bottom-6 left-6 right-6 p-6 glass-card border-brand-primary/20">
              <div className="flex gap-4">
                <Quote className="text-brand-primary shrink-0" size={32} />
                <p className="text-sm font-medium italic text-slate-300">
                  "I specialize in building real-world machine learning models and deriving actionable insights from data. My foundation in Python and deep mathematical understanding allows me to build accurate, optimized solutions."
                </p>
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
        >
          <div className="text-sm font-mono text-brand-primary uppercase tracking-[0.3em] mb-4 font-bold italic">
            01 / Professional Profile
          </div>
          <h2 className="text-4xl md:text-6xl mb-8 leading-tight">
            Decoding Data, <br />
            <span className="text-gradient">Engineering Future.</span>
          </h2>
          <div className="space-y-6 text-slate-400 leading-relaxed text-lg">
            <p>
              I am a Data Scientist with hands-on experience in building real-world machine learning models and deriving actionable insights from complex datasets. My expertise spans across <strong>Python, DSA Problem Solving, and Hypothesis Testing.</strong>
            </p>
            <p>
              With a solid understanding of the mathematical foundations behind AI—including <strong>Statistics, Calculus, and Linear Algebra</strong>—I build accurate predictive models evaluated through rigorous performance metrics.
            </p>
            <p>
              I am passionate about solving real-world problems and am continuously expanding my skills into ML Engineering, deployment, and advanced AI technologies to deliver smarter, data-driven solutions.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-8 mt-12 bg-white/5 p-8 rounded-2xl border border-white/10">
            <div>
              <div className="text-3xl font-bold font-display text-white mb-1">Education</div>
              <div className="text-sm text-slate-500 font-mono uppercase">Inter in CS</div>
              <div className="text-xs text-brand-primary mt-1">Punjab Group of Colleges</div>
            </div>
            <div>
              <div className="text-3xl font-bold font-display text-white mb-1">Location</div>
              <div className="text-sm text-slate-500 font-mono uppercase">Lahore, PK</div>
              <div className="text-xs text-brand-primary mt-1">Remote Available</div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="py-12 px-6 border-t border-white/10 mt-20">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
        <div className="flex flex-col items-start gap-4">
          <div className="flex items-center gap-2 text-[0.75rem] text-text-dim">
            <span className="w-2 h-2 bg-[#22c55e] rounded-full shadow-[0_0_10px_#22c55e]" />
            Available for new challenges
          </div>
          <div className="flex gap-6 text-[0.75rem] font-medium uppercase tracking-[0.1em] text-text-dim">
            <a href="https://www.linkedin.com/in/muhammad-umar-ai-ml" className="hover:text-white transition-colors">LinkedIn</a>
            <a href="https://github.com/MuhammadUmar-official" className="hover:text-white transition-colors">GitHub</a>
            <a href="mailto:hiumar937@gmail.com" className="hover:text-white transition-colors">Email</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default function App() {
  return (
    <div className="relative min-h-screen custom-scrollbar">
      <Background3D />
      <Navbar />
      
      <main>
        <Hero />
        <About />
        <Skills />
        <Experience />
        <Contact />
      </main>

      <Footer />
    </div>
  );
}
